//
// Created by kniku on 04/01/2021.
//

#ifndef TINYCARS_CONSTANTS_H
#define TINYCARS_CONSTANTS_H

#endif //TINYCARS_CONSTANTS_H
/*const  float  parkwidth =80;
const  float  parkheight =40;
const  float  carwidth =80;
const  float  carheight =32;*/